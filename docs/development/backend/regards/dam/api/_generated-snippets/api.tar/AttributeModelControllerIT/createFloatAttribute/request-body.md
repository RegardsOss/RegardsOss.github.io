    ***Data params**

        ```json
    {
  "name" : "FLOAT_ATT",
  "description" : "float description",
  "type" : "DOUBLE",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.FLOAT_ATT"
}
        ```
