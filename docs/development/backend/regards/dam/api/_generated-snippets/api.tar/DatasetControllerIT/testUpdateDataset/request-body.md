    ***Data params**

        ```json
    {
  "type" : "DATASET",
  "metadata" : {
    "dataObjectsGroups" : { }
  },
  "id" : 25,
  "ipId" : "URN:AIP:DATASET:PROJECT:f3d79e74-5c80-40ec-a89c-73e48913200f:V1",
  "creationDate" : "2019-07-19T17:14:54.503Z",
  "model" : {
    "id" : 20,
    "name" : "modelName1",
    "description" : "model desc",
    "type" : "DATASET"
  },
  "tags" : [ "URN:AIP:DATASET:PROJECT:9e4c100c-70d7-4ca6-b2ea-47f31b597e1d:V1" ],
  "groups" : [ ],
  "feature" : {
    "licence" : "licence",
    "providerId" : "ProviderId1",
    "entityType" : "DATASET",
    "label" : "label",
    "model" : "modelName1",
    "files" : { },
    "tags" : [ "URN:AIP:DATASET:PROJECT:9e4c100c-70d7-4ca6-b2ea-47f31b597e1d:V1" ],
    "id" : "URN:AIP:DATASET:PROJECT:f3d79e74-5c80-40ec-a89c-73e48913200f:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
