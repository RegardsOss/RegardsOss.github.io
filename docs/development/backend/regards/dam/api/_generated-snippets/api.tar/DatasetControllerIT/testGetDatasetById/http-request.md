    #### Request

        ***URL**

        `/datasets/17`

        ***URL template**

        `/datasets/{dataset_id}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
