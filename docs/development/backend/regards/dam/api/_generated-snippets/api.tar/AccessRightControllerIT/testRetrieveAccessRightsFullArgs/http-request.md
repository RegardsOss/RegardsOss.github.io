    #### Request

        ***URL**

        `/accessrights?dataset=URN:AIP:DATASET:PROJECT:aaa42286-e558-4c2e-b953-d4aca63e95e7:V1&accessgroup=AG1`

        ***URL template**

        `/accessrights?dataset=URN:AIP:DATASET:PROJECT:aaa42286-e558-4c2e-b953-d4aca63e95e7:V1&accessgroup=AG1`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
