    #### Request

        ***URL**

        `/collections/8`

        ***URL template**

        `/collections/{collection_id}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
