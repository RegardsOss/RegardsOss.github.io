    ***URL params**

        `/models/{modelName}/attributes`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `modelName` |String|Model name|
    {:.table.table-striped}

