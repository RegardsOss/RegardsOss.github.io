    #### Request

        ***URL**

        `/models/attributes/90`

        ***URL template**

        `/models/attributes/{attributeId}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
