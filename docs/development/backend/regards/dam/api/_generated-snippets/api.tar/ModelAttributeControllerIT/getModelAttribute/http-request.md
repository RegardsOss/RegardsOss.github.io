    #### Request

        ***URL**

        `/models/modelGMA/attributes/3`

        ***URL template**

        `/models/{modelName}/attributes/{attributeId}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
