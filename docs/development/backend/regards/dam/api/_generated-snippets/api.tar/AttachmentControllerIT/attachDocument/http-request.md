    #### Request

        ***URL**

        `/entities/URN:AIP:COLLECTION:PROJECT:cbb28c1d-2e9b-4702-83aa-d1926746ae8c:V1/files/33e7816ebf11cf6501548cfa28e4e1de`

        ***URL template**

        `/entities/{urn}/files/{checksum}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
