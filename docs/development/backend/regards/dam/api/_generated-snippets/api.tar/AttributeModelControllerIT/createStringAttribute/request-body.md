    ***Data params**

        ```json
    {
  "name" : "STRING_ATT",
  "description" : "string description",
  "type" : "STRING",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.STRING_ATT"
}
        ```
