    ***Data params**

        ```json
    {
  "datasetIds" : [ ],
  "modelIds" : [ 4 ]
}
        ```
