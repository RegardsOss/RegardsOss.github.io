#### Request

* **Code:** 200 OK

        **Headers:**

        `Pragma:no-cache`
        `X-XSS-Protection:1; mode=block`
        `Expires:0`
        `X-Frame-Options:DENY`
        `X-Content-Type-Options:nosniff`
        `Access-Control-Allow-Headers:authorization, content-type, scope`
        `Access-Control-Max-Age:3600`
        `Content-Type:application/json;charset=UTF-8`
        `Access-Control-Allow-Origin:*`
        `Cache-Control:no-cache, no-store, max-age=0, must-revalidate`
        `Access-Control-Allow-Methods:POST, PUT, GET, OPTIONS, DELETE`

        **Content:**

        ```json
    
{
  "content" : {
    "type" : "COLLECTION",
    "id" : 53,
    "ipId" : "URN:AIP:COLLECTION:PROJECT:11d2c91d-a4ba-43b2-a8e0-9babdfe59658:V1",
    "creationDate" : "2019-07-19T17:14:23.684Z",
    "lastUpdate" : "2019-07-19T17:14:23.716Z",
    "model" : {
      "id" : 203,
      "name" : "TestOptionalNonAlterable",
      "description" : "Sample mission",
      "type" : "COLLECTION"
    },
    "tags" : [ ],
    "groups" : [ ],
    "feature" : {
      "providerId" : "COL4",
      "entityType" : "COLLECTION",
      "label" : "optionalNotGivenNonAlterable",
      "model" : "TestOptionalNonAlterable",
      "files" : { },
      "tags" : [ ],
      "id" : "URN:AIP:COLLECTION:PROJECT:11d2c91d-a4ba-43b2-a8e0-9babdfe59658:V1",
      "properties" : { },
      "type" : "Feature"
    }
  },
  "links" : [ {
    "rel" : "update",
    "href" : "http://localhost:8080/collections/53"
  } ]
}
        ```
