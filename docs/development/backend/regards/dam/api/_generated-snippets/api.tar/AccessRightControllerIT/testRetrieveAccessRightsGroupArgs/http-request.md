    #### Request

        ***URL**

        `/accessrights?accessgroup=AG1`

        ***URL template**

        `/accessrights?accessgroup=AG1`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
