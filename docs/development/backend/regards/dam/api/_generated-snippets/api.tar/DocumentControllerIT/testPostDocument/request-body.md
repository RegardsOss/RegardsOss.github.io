    ***Data params**

        ```json
    {
  "type" : "DOCUMENT",
  "ipId" : "URN:AIP:DOCUMENT:null:49a7cb32-9a0c-4997-9a4a-706901a1a5d9:V1",
  "creationDate" : "2019-07-19T17:14:31.788Z",
  "model" : {
    "id" : 8,
    "name" : "documentModelName1",
    "description" : "model desc",
    "type" : "COLLECTION"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "ProviderId3",
    "entityType" : "DOCUMENT",
    "label" : "label",
    "model" : "documentModelName1",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:DOCUMENT:null:49a7cb32-9a0c-4997-9a4a-706901a1a5d9:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
