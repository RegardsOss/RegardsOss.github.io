    #### Request

        ***URL**

        `/datasources/60`

        ***URL template**

        `/datasources/{pluginConfId}`

        ***Method**

        `PUT`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
