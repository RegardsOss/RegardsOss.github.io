    #### Request

        ***URL**

        `/accessrights/isAccessible?dataset=URN%3AAIP%3ADATASET%3APROJECT%3A26e05bf1-fced-4141-ae2d-bd6e35f30dd9%3AV1&user=not.existingtest%40email.com`

        ***URL template**

        `/accessrights/isAccessible`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
