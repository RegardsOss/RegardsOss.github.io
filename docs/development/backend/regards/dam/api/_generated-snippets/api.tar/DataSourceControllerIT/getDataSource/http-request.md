    #### Request

        ***URL**

        `/datasources/58`

        ***URL template**

        `/datasources/{pluginConfId}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
