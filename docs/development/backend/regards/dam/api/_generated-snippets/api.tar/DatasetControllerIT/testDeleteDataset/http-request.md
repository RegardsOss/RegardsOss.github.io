    #### Request

        ***URL**

        `/datasets/11`

        ***URL template**

        `/datasets/{dataset_id}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
