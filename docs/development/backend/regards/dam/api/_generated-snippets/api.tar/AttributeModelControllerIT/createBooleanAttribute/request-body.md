    ***Data params**

        ```json
    {
  "name" : "BOOLEAN_ATT",
  "description" : "boolean description",
  "type" : "BOOLEAN",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.BOOLEAN_ATT"
}
        ```
