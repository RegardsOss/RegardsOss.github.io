    ***Data params**

        ```json
    {
  "type" : "COLLECTION",
  "id" : 53,
  "ipId" : "URN:AIP:COLLECTION:PROJECT:11d2c91d-a4ba-43b2-a8e0-9babdfe59658:V1",
  "creationDate" : "2019-07-19T17:14:23.684Z",
  "model" : {
    "id" : 203,
    "name" : "TestOptionalNonAlterable",
    "description" : "Sample mission",
    "type" : "COLLECTION"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "COL4",
    "entityType" : "COLLECTION",
    "label" : "optionalNotGivenNonAlterable",
    "model" : "TestOptionalNonAlterable",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:COLLECTION:PROJECT:11d2c91d-a4ba-43b2-a8e0-9babdfe59658:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
