    ***Data params**

        ```json
    {
  "name" : "INTEGER_ATT",
  "description" : "Integer description",
  "type" : "INTEGER",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.INTEGER_ATT"
}
        ```
