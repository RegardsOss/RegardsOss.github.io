    #### Request

        ***URL**

        `/entities/URN:AIP:COLLECTION:PROJECT:0a08b9a4-860d-42e1-b578-a377de2abe15:V1/files/DESCRIPTION`

        ***URL template**

        `/entities/{urn}/files/{dataType}`

        ***Method**

        `POST`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:multipart/form-data;charset=UTF-8; boundary=6o2knFse3p53ty9dmcQvWAIx1zInP11uCfbm`
