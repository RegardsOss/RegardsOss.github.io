    #### Request

        ***URL**

        `/collections/1/associate`

        ***URL template**

        `/collections/{collection_id}/associate`

        ***Method**

        `PUT`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
