    #### Request

        ***URL**

        `/models/modelRmNA/attributes/4`

        ***URL template**

        `/models/{modelName}/attributes/{attributeId}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
