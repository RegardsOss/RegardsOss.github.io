    #### Request

        ***URL**

        `/documents/3/associate`

        ***URL template**

        `/documents/{document_id}/associate`

        ***Method**

        `PUT`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
