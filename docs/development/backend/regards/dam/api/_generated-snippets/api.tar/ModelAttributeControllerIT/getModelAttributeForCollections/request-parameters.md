    ***Query params**

        |Parameter|Type|Description|Constraints| |:-------:|:--:|:---------:|:---------:|
        | `type` |String|Model type for which we want the associations|Available values: COLLECTION, DOCUMENT, DATA, DATASET|
    {:.table.table-striped}
