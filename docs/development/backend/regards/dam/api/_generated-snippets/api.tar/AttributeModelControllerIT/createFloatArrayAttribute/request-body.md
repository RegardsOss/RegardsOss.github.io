    ***Data params**

        ```json
    {
  "name" : "FLOAT_ARRAY_ATT",
  "description" : "float array description",
  "type" : "DOUBLE_ARRAY",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.FLOAT_ARRAY_ATT"
}
        ```
