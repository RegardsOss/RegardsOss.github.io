    ***Data params**

        ```json
    {
  "attribute" : {
    "id" : 27,
    "name" : "attPostAM",
    "type" : "STRING",
    "fragment" : {
      "id" : 6,
      "name" : "default",
      "description" : "Default fragment"
    },
    "alterable" : false,
    "optional" : false,
    "label" : "ForTests",
    "dynamic" : true,
    "internal" : false,
    "jsonPath" : "properties.attPostAM"
  },
  "model" : {
    "id" : 25,
    "name" : "modelPostAM",
    "type" : "COLLECTION"
  },
  "pos" : 0
}
        ```
