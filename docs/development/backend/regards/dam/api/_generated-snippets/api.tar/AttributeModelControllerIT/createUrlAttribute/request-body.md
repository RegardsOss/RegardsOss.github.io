    ***Data params**

        ```json
    {
  "name" : "URL_ATT",
  "description" : "url description",
  "type" : "URL",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.URL_ATT"
}
        ```
