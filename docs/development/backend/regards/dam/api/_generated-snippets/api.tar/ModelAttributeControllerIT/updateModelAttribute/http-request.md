    #### Request

        ***URL**

        `/models/modelUpMA/attributes/30`

        ***URL template**

        `/models/{modelName}/attributes/{attributeId}`

        ***Method**

        `PUT`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
