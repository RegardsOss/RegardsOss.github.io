    ***URL params**

        `/models/{modelName}/attributes/fragments/{fragmentId}`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `modelName` |String|Model name|
        `fragmentId` |Number|Fragment identifier|
    {:.table.table-striped}

