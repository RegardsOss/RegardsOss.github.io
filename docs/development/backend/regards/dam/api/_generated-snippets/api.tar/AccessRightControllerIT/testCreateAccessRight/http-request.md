    #### Request

        ***URL**

        `/accessrights`

        ***URL template**

        `/accessrights`

        ***Method**

        `POST`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
