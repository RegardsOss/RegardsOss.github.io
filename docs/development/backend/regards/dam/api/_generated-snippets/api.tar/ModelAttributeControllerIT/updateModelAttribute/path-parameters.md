    ***URL params**

        `/models/{modelName}/attributes/{attributeId}`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `modelName` |String|Model name|
        `attributeId` |Number|Attribute identifier|
    {:.table.table-striped}

