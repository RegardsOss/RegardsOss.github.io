    #### Request

        ***URL**

        `/entities/URN:AIP:COLLECTION:PROJECT:08326caa-ef20-45ab-92e7-3c1238d2be37:V1/files/33e7816ebf11cf6501548cfa28e4e1de`

        ***URL template**

        `/entities/{urn}/files/{checksum}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
