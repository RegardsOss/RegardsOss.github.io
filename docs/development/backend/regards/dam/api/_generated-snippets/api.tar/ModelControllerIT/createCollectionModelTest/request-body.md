    ***Data params**

        ```json
    {
  "name" : "MISSION",
  "description" : "Mission description",
  "type" : "COLLECTION"
}
        ```
