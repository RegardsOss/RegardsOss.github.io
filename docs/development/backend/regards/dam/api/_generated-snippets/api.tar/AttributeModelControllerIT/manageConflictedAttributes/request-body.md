    ***Data params**

        ```json
    {
  "name" : "ALPHABET",
  "type" : "STRING",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "restriction" : {
    "acceptableValues" : [ "GAMMA", "ALPHA", "BETA" ],
    "type" : "ENUMERATION"
  },
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.ALPHABET"
}
        ```
