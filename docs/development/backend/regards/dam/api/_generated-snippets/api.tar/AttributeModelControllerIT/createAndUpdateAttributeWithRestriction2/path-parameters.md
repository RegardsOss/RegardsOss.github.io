    ***URL params**

        `/models/attributes/{attributeId}`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `attributeId` |Number|attribute id|
    {:.table.table-striped}

