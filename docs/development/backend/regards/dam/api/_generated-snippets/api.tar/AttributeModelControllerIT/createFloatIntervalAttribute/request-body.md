    ***Data params**

        ```json
    {
  "name" : "FLOAT_INTERVAL_ATT",
  "description" : "float interval description",
  "type" : "DOUBLE_INTERVAL",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.FLOAT_INTERVAL_ATT"
}
        ```
