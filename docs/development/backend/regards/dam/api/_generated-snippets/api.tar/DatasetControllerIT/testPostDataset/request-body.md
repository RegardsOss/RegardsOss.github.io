    ***Data params**

        ```json
    {
  "type" : "DATASET",
  "metadata" : {
    "dataObjectsGroups" : { }
  },
  "ipId" : "URN:AIP:DATASET:PROJECT:21caaf70-eed0-4e04-97f7-a2b90b0346cf:V1",
  "creationDate" : "2019-07-19T17:14:54.401Z",
  "model" : {
    "id" : 16,
    "name" : "modelName1",
    "description" : "model desc",
    "type" : "DATASET"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "licence" : "licence",
    "providerId" : "DS21",
    "entityType" : "DATASET",
    "label" : "dataSet21",
    "model" : "modelName1",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:DATASET:PROJECT:21caaf70-eed0-4e04-97f7-a2b90b0346cf:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
