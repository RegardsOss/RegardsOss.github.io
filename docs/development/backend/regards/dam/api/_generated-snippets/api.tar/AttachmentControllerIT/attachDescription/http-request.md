    #### Request

        ***URL**

        `/entities/URN:AIP:COLLECTION:PROJECT:db2db091-35a9-4493-b191-990144e1da70:V1/files/DESCRIPTION`

        ***URL template**

        `/entities/{urn}/files/{dataType}`

        ***Method**

        `POST`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:multipart/form-data;charset=UTF-8; boundary=6o2knFse3p53ty9dmcQvWAIx1zInP11uCfbm`
