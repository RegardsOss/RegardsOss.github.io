    #### Request

        ***URL**

        `/entities/URN:AIP:COLLECTION:PROJECT:1d5a052e-6d53-475a-aeeb-4eda43057052:V1/files/6c342551cb27c952b1e1d380f82f404a`

        ***URL template**

        `/entities/{urn}/files/{checksum}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
