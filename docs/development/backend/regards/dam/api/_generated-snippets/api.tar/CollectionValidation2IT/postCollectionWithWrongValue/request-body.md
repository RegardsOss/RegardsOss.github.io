    ***Data params**

        ```json
    {
  "type" : "COLLECTION",
  "ipId" : "URN:AIP:COLLECTION:null:848c59c7-771f-49a1-ae7c-f1361d7fc977:V1",
  "model" : {
    "id" : 202,
    "name" : "MISSION",
    "description" : "Sample mission",
    "type" : "COLLECTION"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "COL1",
    "entityType" : "COLLECTION",
    "label" : "label",
    "model" : "MISSION",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:COLLECTION:null:848c59c7-771f-49a1-ae7c-f1361d7fc977:V1",
    "properties" : {
      "reference" : "REFTEST",
      "geo" : {
        "crs" : "notEarth"
      },
      "active" : true
    },
    "type" : "Feature"
  }
}
        ```
