    ***URL params**

        `/models/attributes/modeltype/{modelType}`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `modelType` |String|model type|Available values: COLLECTION, DOCUMENT, DATA, DATASET
    {:.table.table-striped}

