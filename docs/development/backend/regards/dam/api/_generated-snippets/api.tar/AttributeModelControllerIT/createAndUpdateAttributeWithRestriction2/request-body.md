    ***Data params**

        ```json
    {
  "id" : 30,
  "name" : "NB_OBJECTS",
  "type" : "LONG",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "restriction" : {
    "min" : 10,
    "max" : 100,
    "minExcluded" : false,
    "maxExcluded" : false,
    "type" : "LONG_RANGE"
  },
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.NB_OBJECTS"
}
        ```
