    ***Query params**

        |Parameter|Type|Description|Constraints| |:-------:|:--:|:---------:|:---------:|
        | `type` |String|Attribute type|Available values: STRING, INTEGER, DOUBLE, DATE_ISO8601, URL, BOOLEAN, STRING_ARRAY, INTEGER_ARRAY, DOUBLE_ARRAY, DATE_ARRAY, INTEGER_INTERVAL, DOUBLE_INTERVAL, DATE_INTERVAL, LONG, LONG_INTERVAL, LONG_ARRAY|
    {:.table.table-striped}
