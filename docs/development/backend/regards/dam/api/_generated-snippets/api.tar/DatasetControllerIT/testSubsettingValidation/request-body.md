    ***Data params**

        ```json
    {
  "query" : "properties.DO_NOT_EXIST:10"
}
        ```
