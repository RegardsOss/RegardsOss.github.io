    ***Data params**

        ```json
    {
  "name" : "NameIsNeeded",
  "users" : [ ],
  "isPublic" : false,
  "isInternal" : false
}
        ```
