    ***Data params**

        ```json
    {
  "type" : "COLLECTION",
  "id" : 1,
  "ipId" : "URN:AIP:COLLECTION:PROJECT:6ec1570f-abf4-4487-8dfd-34d5bc2362fc:V1",
  "creationDate" : "2019-07-19T17:14:38.515Z",
  "model" : {
    "id" : 1,
    "name" : "modelName1",
    "description" : "model desc",
    "type" : "COLLECTION"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "ProviderId1new",
    "entityType" : "COLLECTION",
    "label" : "label",
    "model" : "modelName1",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:COLLECTION:PROJECT:6ec1570f-abf4-4487-8dfd-34d5bc2362fc:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
