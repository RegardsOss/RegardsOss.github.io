    ***Data params**

        ```json
    {
  "type" : "COLLECTION",
  "id" : 10,
  "ipId" : "URN:AIP:COLLECTION:PROJECT:e6487905-90e3-4245-bd8f-54bde6fd58c1:V1",
  "creationDate" : "2019-07-19T17:14:39.078Z",
  "model" : {
    "id" : 5,
    "name" : "modelName1",
    "description" : "model desc",
    "type" : "COLLECTION"
  },
  "tags" : [ "URN:AIP:COLLECTION:PROJECT:0bf9da68-4e33-45b3-9704-e3e0188dc54c:V1" ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "ProviderId1new",
    "entityType" : "COLLECTION",
    "label" : "collection1clone",
    "model" : "modelName1",
    "files" : { },
    "tags" : [ "URN:AIP:COLLECTION:PROJECT:0bf9da68-4e33-45b3-9704-e3e0188dc54c:V1" ],
    "id" : "URN:AIP:COLLECTION:PROJECT:e6487905-90e3-4245-bd8f-54bde6fd58c1:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
