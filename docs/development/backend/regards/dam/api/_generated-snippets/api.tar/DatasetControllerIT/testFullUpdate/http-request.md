    #### Request

        ***URL**

        `/datasets/5`

        ***URL template**

        `/datasets/{dataset_id}`

        ***Method**

        `PUT`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
