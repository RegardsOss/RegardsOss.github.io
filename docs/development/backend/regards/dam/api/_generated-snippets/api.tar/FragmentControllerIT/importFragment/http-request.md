    #### Request

        ***URL**

        `/models/fragments/import`

        ***URL template**

        `/models/fragments/import`

        ***Method**

        `POST`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:multipart/form-data;charset=UTF-8; boundary=6o2knFse3p53ty9dmcQvWAIx1zInP11uCfbm`
