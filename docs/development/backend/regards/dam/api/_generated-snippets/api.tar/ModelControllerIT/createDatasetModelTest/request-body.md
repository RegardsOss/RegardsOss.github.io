    ***Data params**

        ```json
    {
  "name" : "DATASET",
  "description" : "Dataset description",
  "type" : "DATASET"
}
        ```
