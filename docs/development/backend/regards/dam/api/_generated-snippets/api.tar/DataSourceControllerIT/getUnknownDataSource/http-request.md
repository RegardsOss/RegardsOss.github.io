    #### Request

        ***URL**

        `/datasources/9223372036854775807`

        ***URL template**

        `/datasources/{pluginConfId}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
