    ***Data params**

        ```json
    {
  "name" : "INTEGER_INTERVAL_ATT",
  "description" : "Integer interval description",
  "type" : "INTEGER_INTERVAL",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.INTEGER_INTERVAL_ATT"
}
        ```
