    ***Data params**

        ```json
    {
  "name" : "STRING_ARRAY_ATT",
  "description" : "string array description",
  "type" : "STRING_ARRAY",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.STRING_ARRAY_ATT"
}
        ```
