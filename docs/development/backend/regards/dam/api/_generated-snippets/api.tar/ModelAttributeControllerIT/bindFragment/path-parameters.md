    ***URL params**

        `/models/{modelName}/attributes/fragments`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `modelName` |String|Model name|
    {:.table.table-striped}

