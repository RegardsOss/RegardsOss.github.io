    ***URL params**

        `/models/{modelName}/attributes`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `modelName` |String|model name|
    {:.table.table-striped}

