    #### Request

        ***URL**

        `/models/modelDeleteFrag/attributes/fragments/5`

        ***URL template**

        `/models/{modelName}/attributes/fragments/{fragmentId}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
