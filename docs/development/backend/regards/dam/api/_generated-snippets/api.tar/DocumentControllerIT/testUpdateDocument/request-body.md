    ***Data params**

        ```json
    {
  "type" : "DOCUMENT",
  "id" : 11,
  "ipId" : "URN:AIP:DOCUMENT:PROJECT:702f3d2a-0c32-4702-922e-a07941c3da83:V1",
  "creationDate" : "2019-07-19T17:14:31.275Z",
  "model" : {
    "id" : 5,
    "name" : "documentModelName2",
    "description" : "model desc",
    "type" : "DOCUMENT"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "ProviderId2new",
    "entityType" : "DOCUMENT",
    "label" : "document1clone",
    "model" : "documentModelName2",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:DOCUMENT:PROJECT:702f3d2a-0c32-4702-922e-a07941c3da83:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
