    ***Data params**

        ```json
    [ "URN:AIP:COLLECTION:PROJECT:7107db96-1227-4812-ba99-2d512ca52b4d:V1" ]
        ```
