#### Request

* **Code:** 200 OK

        **Headers:**

        `Pragma:no-cache`
        `X-XSS-Protection:1; mode=block`
        `Expires:0`
        `X-Frame-Options:DENY`
        `X-Content-Type-Options:nosniff`
        `Access-Control-Allow-Headers:authorization, content-type, scope`
        `Access-Control-Max-Age:3600`
        `Content-Type:application/json;charset=UTF-8`
        `Access-Control-Allow-Origin:*`
        `Cache-Control:no-cache, no-store, max-age=0, must-revalidate`
        `Access-Control-Allow-Methods:POST, PUT, GET, OPTIONS, DELETE`

        **Content:**

        ```json
    
{
  "content" : {
    "type" : "COLLECTION",
    "id" : 1,
    "ipId" : "URN:AIP:COLLECTION:PROJECT:6ec1570f-abf4-4487-8dfd-34d5bc2362fc:V1",
    "creationDate" : "2019-07-19T17:14:38.515Z",
    "lastUpdate" : "2019-07-19T17:14:38.749Z",
    "model" : {
      "id" : 1,
      "name" : "modelName1",
      "description" : "model desc",
      "type" : "COLLECTION"
    },
    "tags" : [ ],
    "groups" : [ ],
    "feature" : {
      "providerId" : "ProviderId1new",
      "entityType" : "COLLECTION",
      "label" : "label",
      "model" : "modelName1",
      "files" : { },
      "tags" : [ ],
      "id" : "URN:AIP:COLLECTION:PROJECT:6ec1570f-abf4-4487-8dfd-34d5bc2362fc:V1",
      "properties" : { },
      "type" : "Feature"
    }
  },
  "links" : [ {
    "rel" : "update",
    "href" : "http://localhost:8080/collections/1"
  } ]
}
        ```
