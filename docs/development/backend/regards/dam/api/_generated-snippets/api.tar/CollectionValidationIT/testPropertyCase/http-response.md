#### Request

* **Code:** 201 Created

        **Headers:**

        `Pragma:no-cache`
        `X-XSS-Protection:1; mode=block`
        `Expires:0`
        `X-Frame-Options:DENY`
        `X-Content-Type-Options:nosniff`
        `Access-Control-Allow-Headers:authorization, content-type, scope`
        `Access-Control-Max-Age:3600`
        `Content-Type:application/json;charset=UTF-8`
        `Access-Control-Allow-Origin:*`
        `Cache-Control:no-cache, no-store, max-age=0, must-revalidate`
        `Access-Control-Allow-Methods:POST, PUT, GET, OPTIONS, DELETE`

        **Content:**

        ```json
    
{
  "content" : {
    "type" : "COLLECTION",
    "id" : 102,
    "ipId" : "URN:AIP:COLLECTION:PROJECT:f052aeff-6a5f-4027-9cbf-5eae5e8b80ba:V1",
    "creationDate" : "2019-07-19T17:15:07.191Z",
    "model" : {
      "id" : 253,
      "name" : "MISSION_WITH_LABEL",
      "description" : "Sample mission",
      "type" : "COLLECTION"
    },
    "tags" : [ ],
    "groups" : [ ],
    "feature" : {
      "providerId" : "COL1",
      "entityType" : "COLLECTION",
      "label" : "mission",
      "model" : "MISSION_WITH_LABEL",
      "files" : { },
      "tags" : [ ],
      "id" : "URN:AIP:COLLECTION:PROJECT:f052aeff-6a5f-4027-9cbf-5eae5e8b80ba:V1",
      "properties" : {
        "LABEL" : "uppercaselabel"
      },
      "type" : "Feature"
    }
  },
  "links" : [ ]
}
        ```
