    #### Request

        ***URL**

        `/accessrights?dataset=URN:AIP:DATASET:PROJECT:2346cb86-c683-4161-83fc-77d7548051fd:V1`

        ***URL template**

        `/accessrights?dataset=URN:AIP:DATASET:PROJECT:2346cb86-c683-4161-83fc-77d7548051fd:V1`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
