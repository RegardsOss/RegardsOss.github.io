    ***Data params**

        ```json
    {
  "name" : "DATA_MODEL",
  "description" : "Data model description",
  "type" : "DATA"
}
        ```
