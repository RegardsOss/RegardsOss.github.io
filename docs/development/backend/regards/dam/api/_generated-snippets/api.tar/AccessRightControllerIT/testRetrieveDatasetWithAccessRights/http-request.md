    #### Request

        ***URL**

        `/datasets/access-rights/group/AG1`

        ***URL template**

        `/datasets/access-rights/group/{accessGroupName}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
