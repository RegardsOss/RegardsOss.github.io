    ***Data params**

        ```json
    {
  "id" : 45,
  "name" : "NB_OBJECTS",
  "type" : "INTEGER",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "restriction" : {
    "min" : 10,
    "max" : 100,
    "minExcluded" : false,
    "maxExcluded" : false,
    "type" : "INTEGER_RANGE"
  },
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.NB_OBJECTS"
}
        ```
