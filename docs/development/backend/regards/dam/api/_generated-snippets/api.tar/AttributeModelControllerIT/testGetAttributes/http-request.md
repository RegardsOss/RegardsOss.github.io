    #### Request

        ***URL**

        `/models/attributes`

        ***URL template**

        `/models/attributes`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
