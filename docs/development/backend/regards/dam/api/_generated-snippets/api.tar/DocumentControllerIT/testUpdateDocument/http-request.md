    #### Request

        ***URL**

        `/documents/11`

        ***URL template**

        `/documents/{document_id}`

        ***Method**

        `PUT`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
