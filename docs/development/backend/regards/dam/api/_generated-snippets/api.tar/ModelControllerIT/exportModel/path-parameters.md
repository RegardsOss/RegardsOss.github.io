    ***URL params**

        `/models/{modelName}/export`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `modelName` |String|model name|
    {:.table.table-striped}

