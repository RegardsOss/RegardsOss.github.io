    ***Data params**

        ```json
    {
  "type" : "COLLECTION",
  "id" : 54,
  "ipId" : "URN:AIP:COLLECTION:PROJECT:c89a6a79-2a82-43f2-b466-67ddc5c13cb2:V1",
  "creationDate" : "2019-07-19T17:14:23.818Z",
  "model" : {
    "id" : 204,
    "name" : "MISSION",
    "description" : "Sample mission",
    "type" : "COLLECTION"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "NEW1",
    "entityType" : "COLLECTION",
    "label" : "label",
    "model" : "MISSION",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:COLLECTION:PROJECT:c89a6a79-2a82-43f2-b466-67ddc5c13cb2:V1",
    "properties" : {
      "reference" : "REFTESTnew",
      "geo" : {
        "crs" : "Earth"
      },
      "active" : false
    },
    "type" : "Feature"
  }
}
        ```
