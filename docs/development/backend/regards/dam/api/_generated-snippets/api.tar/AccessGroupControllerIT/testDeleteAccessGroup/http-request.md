    #### Request

        ***URL**

        `/accessgroups/AG2`

        ***URL template**

        `/accessgroups/{name}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
