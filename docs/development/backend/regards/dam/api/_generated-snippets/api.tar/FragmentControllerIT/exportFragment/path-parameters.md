    ***URL params**

        `/models/fragments/{fragmentId}/export`

        Parameter|Type|Description|Constraints
        :-------:|:--:|:---------:|:---------:
        `fragmentId` |Number|Fragment identifier|Should be a whole number
    {:.table.table-striped}

