    ***Data params**

        ```json
    {
  "name" : "DATE_ARRAY_ATT",
  "description" : "date array description",
  "type" : "DATE_ARRAY",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.DATE_ARRAY_ATT"
}
        ```
