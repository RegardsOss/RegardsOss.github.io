    #### Request

        ***URL**

        `/models/fragments/6/export`

        ***URL template**

        `/models/fragments/{fragmentId}/export`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
