    ***Data params**

        ```json
    {
  "name" : "DOCUMENT",
  "description" : "Document description",
  "type" : "DOCUMENT"
}
        ```
