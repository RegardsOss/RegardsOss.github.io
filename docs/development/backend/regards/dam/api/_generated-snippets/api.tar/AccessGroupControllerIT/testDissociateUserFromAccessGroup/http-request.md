    #### Request

        ***URL**

        `/accessgroups/AG1/user1@user1.user1`

        ***URL template**

        `/accessgroups/{name}/{email}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
