    ***Data params**

        ```json
    {
  "id" : 30,
  "attribute" : {
    "id" : 31,
    "name" : "attnewUpMA",
    "type" : "STRING",
    "fragment" : {
      "id" : 8,
      "name" : "default",
      "description" : "Default fragment"
    },
    "alterable" : false,
    "optional" : false,
    "label" : "ForTests",
    "dynamic" : true,
    "internal" : false,
    "jsonPath" : "properties.attnewUpMA"
  },
  "model" : {
    "id" : 27,
    "name" : "modelUpMA",
    "type" : "COLLECTION"
  },
  "pos" : 0
}
        ```
