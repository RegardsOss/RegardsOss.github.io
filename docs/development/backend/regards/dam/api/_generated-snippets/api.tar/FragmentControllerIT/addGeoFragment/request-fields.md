    |Path|Type|Description|Constraints| |:--:|:--:|:---------:|:---------:|
        |name| `String` |Fragment Name|Must match the regular expression `[a-zA-Z_][0-9a-zA-Z_]*`, Must not be null, Size must be between 1 and 32 inclusive|
        |description| `String` |Fragment description|Optional|
        |version| `String` |Fragment Version|Size must be between 0 and 16 inclusive. Optional|
    {:.table.table-striped}
