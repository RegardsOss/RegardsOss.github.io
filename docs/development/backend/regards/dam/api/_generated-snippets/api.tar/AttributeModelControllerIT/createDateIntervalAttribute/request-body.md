    ***Data params**

        ```json
    {
  "name" : "DATE_INTERV_ATT",
  "description" : "date interval description",
  "type" : "DATE_INTERVAL",
  "alterable" : false,
  "optional" : false,
  "label" : "ForTests",
  "dynamic" : true,
  "internal" : false,
  "jsonPath" : "properties.DATE_INTERV_ATT"
}
        ```
