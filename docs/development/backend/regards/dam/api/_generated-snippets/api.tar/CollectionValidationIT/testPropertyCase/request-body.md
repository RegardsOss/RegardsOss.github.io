    ***Data params**

        ```json
    {
  "type" : "COLLECTION",
  "ipId" : "URN:AIP:COLLECTION:PROJECT:f052aeff-6a5f-4027-9cbf-5eae5e8b80ba:V1",
  "model" : {
    "id" : 253,
    "name" : "MISSION_WITH_LABEL",
    "description" : "Sample mission",
    "type" : "COLLECTION"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "COL1",
    "entityType" : "COLLECTION",
    "label" : "mission",
    "model" : "MISSION_WITH_LABEL",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:COLLECTION:PROJECT:f052aeff-6a5f-4027-9cbf-5eae5e8b80ba:V1",
    "properties" : {
      "LABEL" : "uppercaselabel"
    },
    "type" : "Feature"
  }
}
        ```
