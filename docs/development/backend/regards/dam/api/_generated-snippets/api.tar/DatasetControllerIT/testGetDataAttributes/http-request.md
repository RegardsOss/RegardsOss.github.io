    #### Request

        ***URL**

        `/datasets/data/attributes?page=1`

        ***URL template**

        `/datasets/data/attributes?page=1`

        ***Method**

        `POST`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
