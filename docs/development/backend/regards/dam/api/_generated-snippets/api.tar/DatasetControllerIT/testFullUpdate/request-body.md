    ***Data params**

        ```json
    {
  "type" : "DATASET",
  "metadata" : {
    "dataObjectsGroups" : { }
  },
  "id" : 5,
  "ipId" : "URN:AIP:DATASET:PROJECT:4f9284af-68f1-41a3-86aa-fb617cc72893:V1",
  "creationDate" : "2019-07-19T17:14:53.158Z",
  "model" : {
    "id" : 5,
    "name" : "modelName1",
    "description" : "model desc",
    "type" : "DATASET"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "licence" : "licence",
    "providerId" : "ProviderId1new",
    "entityType" : "DATASET",
    "label" : "label",
    "model" : "modelName1",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:DATASET:PROJECT:4f9284af-68f1-41a3-86aa-fb617cc72893:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
