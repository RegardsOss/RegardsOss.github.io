    #### Request

        ***URL**

        `/models/attributes/49`

        ***URL template**

        `/models/attributes/{attributeId}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
