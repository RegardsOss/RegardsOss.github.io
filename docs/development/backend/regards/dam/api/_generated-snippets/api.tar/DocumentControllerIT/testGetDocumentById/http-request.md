    #### Request

        ***URL**

        `/documents/7`

        ***URL template**

        `/documents/{document_id}`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
