    #### Request

        ***URL**

        `/accessrights/1`

        ***URL template**

        `/accessrights/{accessright_id}`

        ***Method**

        `DELETE`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
