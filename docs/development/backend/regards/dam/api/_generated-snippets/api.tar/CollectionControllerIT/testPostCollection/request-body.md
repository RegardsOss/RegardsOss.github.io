    ***Data params**

        ```json
    {
  "type" : "COLLECTION",
  "ipId" : "URN:AIP:COLLECTION:null:751343a9-eb1a-4b85-8d20-7fc378de9752:V1",
  "creationDate" : "2019-07-19T17:14:38.979Z",
  "model" : {
    "id" : 3,
    "name" : "modelName1",
    "description" : "model desc",
    "type" : "COLLECTION"
  },
  "tags" : [ ],
  "groups" : [ ],
  "feature" : {
    "providerId" : "COL2",
    "entityType" : "COLLECTION",
    "label" : "collection2",
    "model" : "modelName1",
    "files" : { },
    "tags" : [ ],
    "id" : "URN:AIP:COLLECTION:null:751343a9-eb1a-4b85-8d20-7fc378de9752:V1",
    "properties" : { },
    "type" : "Feature"
  }
}
        ```
