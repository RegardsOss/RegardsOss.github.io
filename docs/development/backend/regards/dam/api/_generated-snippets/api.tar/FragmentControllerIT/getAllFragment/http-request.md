    #### Request

        ***URL**

        `/models/fragments`

        ***URL template**

        `/models/fragments`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
