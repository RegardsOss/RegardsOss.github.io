    #### Request

        ***URL**

        `/opensearch/descriptor?url=https%3A%2F%2Ftheia.cnes.fr%2Fatdistrib%2Fresto2%2Fapi%2Fcollections%2Fdescribe.xml`

        ***URL template**

        `/opensearch/descriptor`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
