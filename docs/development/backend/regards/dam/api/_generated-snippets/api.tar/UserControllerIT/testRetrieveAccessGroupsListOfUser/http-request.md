    #### Request

        ***URL**

        `/users/user1@user1.user1/accessgroups`

        ***URL template**

        `/users/{email}/accessgroups`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
