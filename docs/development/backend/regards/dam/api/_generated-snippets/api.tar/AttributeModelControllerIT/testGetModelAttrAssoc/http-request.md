    #### Request

        ***URL**

        `/models/DataModel/attributes`

        ***URL template**

        `/models/{modelName}/attributes`

        ***Method**

        `GET`

        ***Headers**

        `Authorization:Bearer{token}`
        `Accept:application/json`
        `Content-Type:application/json;charset=UTF-8`
